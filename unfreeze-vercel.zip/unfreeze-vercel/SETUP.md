# Unfreeze on Vercel — setup + the 404 fix

## Why the whole site was 404ing

Two likely causes, both fixed by using this folder as-is:

1. **The function format was wrong.** The version I gave you before was
   written for Netlify (`netlify/functions/...`, a different function
   signature). Vercel doesn't read that at all — it uses its own `/api`
   folder convention. This folder now has `api/verify-payment.js` in
   Vercel's format instead.

2. **The file location in your repo.** Vercel expects `index.html` at the
   **root** of what it deploys. If your GitHub repo has it nested inside a
   subfolder (e.g. you uploaded the whole `unfreeze-project` folder as a
   folder *inside* the repo, rather than its contents *being* the repo),
   Vercel won't find it and the whole site 404s. Two ways to fix this:
   - **Easiest:** make sure `index.html`, `api/`, and `package.json` sit
     directly in your repo's root — not inside a subfolder. Re-upload the
     contents of this folder (not the folder itself) to the repo root.
   - **Or:** in Vercel, go to your Project → **Settings → General → Root
     Directory**, and point it at the subfolder your files are actually in
     (e.g. `unfreeze-project`). Then redeploy.

## Full setup steps

### 1. Create a Stripe account
https://dashboard.stripe.com/register — free. Stay in **Test mode** while
setting up (toggle top-right).

### 2. Create a Payment Link
Stripe Dashboard → **Payment links → New**. Product: "Unfreeze — Full
Access", price **£8.00 GBP**, one-time (not recurring). Under "After
payment", choose **Redirect customers to your website** and set:
```
https://YOUR-PROJECT.vercel.app/?session_id={CHECKOUT_SESSION_ID}
```
(You'll get your real `.vercel.app` URL in step 5 — come back and update
this afterwards.)

### 3. Get your Stripe secret key
Dashboard → **Developers → API keys** → copy the **Secret key**
(`sk_test_...`). Never put this in `index.html` — it only goes in Vercel's
environment variables (step 6).

### 4. Add your Payment Link to the app
In `index.html`, find:
```js
const STRIPE_PAYMENT_LINK = 'https://buy.stripe.com/REPLACE_WITH_YOUR_LINK';
```
Replace with your real Payment Link URL from step 2.

### 5. Deploy to Vercel
1. Push the **contents** of this folder to a GitHub repo (root level —
   see the fix above).
2. https://vercel.com → **Add New → Project** → import that repo → Deploy.
   No special configuration needed; Vercel auto-detects the `/api` folder.
3. Copy your live `.vercel.app` URL.

### 6. Add your Stripe secret key to Vercel
Project → **Settings → Environment Variables** → add:
- Key: `STRIPE_SECRET_KEY`
- Value: your `sk_test_...` key from step 3

Then **redeploy** (Deployments tab → ⋯ → Redeploy) so the function picks
it up.

### 7. Update the Payment Link's redirect URL
Back in Stripe (step 2's link), edit it and paste your real `.vercel.app`
URL into the redirect field.

### 8. Test it
Visit your live site, add a debt, click **Unlock — £8**, pay with Stripe's
test card `4242 4242 4242 4242` (any future expiry, any CVC, any
postcode). You should land back on your site and see "Payment confirmed"
within a second or two.

### 9. Go live
Flip Stripe to **Live mode**, recreate the Payment Link in Live mode, grab
the **Live** secret key, and swap both the link in `index.html` and the
`STRIPE_SECRET_KEY` env var in Vercel to the live versions. Redeploy.

## Good to know
Same as before: the unlock is stored per-browser (no accounts yet), so it
won't follow someone to a new device. That's fine to start; if it becomes
a real limitation once you have paying users, adding a lightweight
account system (e.g. Supabase) is the natural next step.
