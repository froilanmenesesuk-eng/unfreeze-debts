// netlify/functions/verify-payment.js
//
// This runs on Netlify's servers (not in the browser), so it's safe to use
// your Stripe SECRET key here. Set it as an environment variable in Netlify:
// Site settings -> Environment variables -> STRIPE_SECRET_KEY = sk_live_xxx (or sk_test_xxx while testing)
//
// It takes a Stripe Checkout Session ID (passed back to your site in the URL
// after a successful payment) and asks Stripe directly whether that session
// was really paid. The browser can't be trusted to say "yes I paid" on its
// own -- this function is what makes the unlock real.

const Stripe = require('stripe');

exports.handler = async function (event) {
  const sessionId = event.queryStringParameters && event.queryStringParameters.session_id;

  if (!sessionId) {
    return {
      statusCode: 400,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Missing session_id' }),
    };
  }

  if (!process.env.STRIPE_SECRET_KEY) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Server is not configured with a Stripe secret key yet.' }),
    };
  }

  try {
    const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
    const session = await stripe.checkout.sessions.retrieve(sessionId);

    const paid = session.payment_status === 'paid';

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        paid,
        email: session.customer_details ? session.customer_details.email : null,
      }),
    };
  } catch (err) {
    console.error('Stripe verification error:', err.message);
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Could not verify this payment.' }),
    };
  }
};
