# Unfreeze — one-time £8 unlock setup

This folder is a small, real deployment: the app (`index.html`) plus one
serverless function (`netlify/functions/verify-payment.js`) that confirms a
payment really happened before unlocking the full features. Follow these
steps in order — the whole thing is free to set up (Stripe only takes a fee
per transaction; Netlify's free tier covers this easily).

## 1. Create your Stripe account
Go to https://dashboard.stripe.com/register and sign up. It's free.
Stay in **Test mode** (toggle top-right of the dashboard) while you're
setting this up — you can switch to Live mode once everything works.

## 2. Create a Payment Link for the £8 unlock
1. In the Stripe Dashboard, go to **Payment links** → **New**.
2. Add a product: name it "Unfreeze — Full Access", price **£8.00 GBP**,
   and make sure it's set to a **one-time** payment (not recurring).
3. Under **After payment**, choose "Don't show confirmation page" →
   **Redirect customers to your website**, and set the URL to:
   ```
   https://YOUR-SITE-NAME.netlify.app/?session_id={CHECKOUT_SESSION_ID}
   ```
   (You'll get your real `.netlify.app` address in step 5 — you can come
   back and paste it in here afterwards.)
4. Save the link. Copy the URL it gives you (looks like
   `https://buy.stripe.com/xxxxxxxx`).

## 3. Get your Stripe secret key
In the Dashboard, go to **Developers → API keys**. Copy the
**Secret key** (starts with `sk_test_...` in test mode). Keep this private —
never put it in `index.html` or anywhere in the browser code.

## 4. Drop your Payment Link into the app
Open `index.html`, find this line near the top of the `<script>` section:
```js
const STRIPE_PAYMENT_LINK = 'https://buy.stripe.com/REPLACE_WITH_YOUR_LINK';
```
Replace it with the real Payment Link URL from step 2.

## 5. Deploy to Netlify (via GitHub, so the function works)
Serverless functions need a proper deploy — not the drag-and-drop uploader.
1. Create a free GitHub account if you don't have one, and a new repository.
2. Upload everything in this folder to that repo, keeping the folder
   structure exactly as-is (`index.html`, `netlify.toml`, `package.json`,
   and the `netlify/functions/` folder).
3. Go to https://app.netlify.com → **Add new site → Import an existing
   project** → connect GitHub → pick the repo.
4. Netlify will detect `netlify.toml` automatically. Click **Deploy**.
5. Once it's live, copy your site's `.netlify.app` URL and paste it into
   the Payment Link's redirect URL from step 2 (Stripe Dashboard → Payment
   links → your link → edit → after payment).

## 6. Add your Stripe secret key to Netlify
1. In Netlify: **Site settings → Environment variables → Add a variable**.
2. Key: `STRIPE_SECRET_KEY`
   Value: the `sk_test_...` key from step 3.
3. Redeploy the site (Netlify → Deploys → Trigger deploy) so the function
   picks up the new variable.

## 7. Test it
1. Open your live site, add a debt or two, click **Unlock — £8** in the
   sidebar.
2. Pay with Stripe's test card: `4242 4242 4242 4242`, any future expiry,
   any CVC, any postcode.
3. You should be redirected back to your site and see "Payment confirmed —
   full access unlocked" within a second or two, with Budget and Payoff
   Plan now open.

## 8. Go live
When you're ready to take real payments: flip Stripe from Test to Live
mode (top-right toggle), create the same Payment Link again in Live mode,
grab your **Live** secret key, and update the Payment Link URL in
`index.html` and the `STRIPE_SECRET_KEY` environment variable in Netlify
with the live versions. Redeploy.

## Good to know
- This unlock is stored in the visitor's own browser (same local-only
  model as the rest of the app). If someone clears their browser data or
  opens the app on a different device, they'll need to pay again — there
  are no accounts yet. If that becomes a problem once you have real
  customers, the next step is adding a lightweight account system (e.g.
  Supabase) so an unlock follows a person rather than a browser.
- Refunds/support: if someone asks for a refund, you handle that directly
  in the Stripe Dashboard — there's nothing else to undo on the app side.
